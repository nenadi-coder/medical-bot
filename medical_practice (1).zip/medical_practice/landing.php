<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dr. John Clinic - Medical Practice Management</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            overflow-x: hidden;
        }

        /* Animated background */
        body::before {
            content: '';
            position: absolute;
            width: 100%;
            height: 100%;
            background: radial-gradient(circle at 20% 50%, rgba(255,255,255,0.1) 0%, transparent 50%);
            pointer-events: none;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
            position: relative;
            z-index: 1;
        }

        .main-card {
            background: white;
            border-radius: 32px;
            overflow: hidden;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
            width: 100%;
            max-width: 1200px;
            display: flex;
            flex-wrap: wrap;
        }

        /* Left side - Branding */
        .brand-side {
            flex: 1;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 48px;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .brand-icon {
            font-size: 64px;
            margin-bottom: 24px;
        }

        .brand-side h1 {
            font-size: 36px;
            margin-bottom: 16px;
            font-weight: 700;
        }

        .brand-side p {
            font-size: 16px;
            opacity: 0.9;
            line-height: 1.6;
            margin-bottom: 32px;
        }

        .features-list {
            list-style: none;
            margin-top: 32px;
        }

        .features-list li {
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .features-list i {
            font-size: 20px;
        }

        /* Right side - Portal Selection */
        .portal-side {
            flex: 1;
            padding: 48px;
            background: white;
        }

        .portal-side h2 {
            font-size: 28px;
            color: #1f2937;
            margin-bottom: 8px;
        }

        .portal-side .subtitle {
            color: #6b7280;
            margin-bottom: 32px;
            font-size: 14px;
        }

        .portals-grid {
            display: flex;
            flex-direction: column;
            gap: 16px;
            margin-bottom: 32px;
        }

        .portal-card {
            display: flex;
            align-items: center;
            gap: 20px;
            padding: 20px;
            background: #f9fafb;
            border-radius: 20px;
            cursor: pointer;
            transition: all 0.3s;
            border: 2px solid transparent;
            text-decoration: none;
        }

        .portal-card:hover {
            transform: translateX(8px);
            background: white;
            border-color: #667eea;
            box-shadow: 0 10px 25px -5px rgba(102, 126, 234, 0.2);
        }

        .portal-icon {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, #667eea15 0%, #764ba215 100%);
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
        }

        .portal-info h3 {
            font-size: 20px;
            color: #1f2937;
            margin-bottom: 4px;
        }

        .portal-info p {
            font-size: 14px;
            color: #6b7280;
        }

        .portal-arrow {
            margin-left: auto;
            color: #667eea;
            font-size: 20px;
        }

        .demo-credentials {
            background: #f3f4f6;
            border-radius: 16px;
            padding: 20px;
            margin-top: 24px;
        }

        .demo-title {
            font-weight: 700;
            margin-bottom: 12px;
            color: #374151;
            font-size: 14px;
        }

        .demo-item {
            font-size: 12px;
            color: #6b7280;
            margin-bottom: 6px;
            font-family: monospace;
        }

        .register-link {
            text-align: center;
            margin-top: 24px;
            padding-top: 24px;
            border-top: 1px solid #e5e7eb;
        }

        .register-link a {
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
        }

        @media (max-width: 768px) {
            .main-card {
                flex-direction: column;
            }
            
            .brand-side {
                padding: 32px;
                text-align: center;
            }
            
            .features-list {
                text-align: left;
            }
            
            .portal-side {
                padding: 32px;
            }
            
            .portal-card:hover {
                transform: translateX(0);
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="main-card">
            <!-- Left side - Branding -->
            <div class="brand-side">
                <div>
                    <div class="brand-icon">🏥</div>
                    <h1>Dr. John Clinic</h1>
                    <p>Complete medical practice management system for modern healthcare</p>
                    
                    <ul class="features-list">
                        <li><i class="fas fa-check-circle"></i> <span>Book & manage appointments</span></li>
                        <li><i class="fas fa-check-circle"></i> <span>Access medical records & lab results</span></li>
                        <li><i class="fas fa-check-circle"></i> <span>Real-time queue position tracking</span></li>
                        <li><i class="fas fa-check-circle"></i> <span>Digital prescriptions & e-signature</span></li>
                        <li><i class="fas fa-check-circle"></i> <span>Secure messaging with doctors</span></li>
                    </ul>
                </div>
            </div>
            
            <!-- Right side - Portal Selection -->
            <div class="portal-side">
                <h2>Welcome Back</h2>
                <p class="subtitle">Select your portal to continue</p>
                
                <div class="portals-grid">
                    <a href="index.php?role=patient" class="portal-card">
                        <div class="portal-icon">👤</div>
                        <div class="portal-info">
                            <h3>Patient Portal</h3>
                            <p>Book appointments, access records & track queue</p>
                        </div>
                        <div class="portal-arrow">→</div>
                    </a>
                    
                    <a href="index.php?role=nurse" class="portal-card">
                        <div class="portal-icon">👩‍⚕️</div>
                        <div class="portal-info">
                            <h3>Nurse Portal</h3>
                            <p>Manage queue, confirm attendance & print tickets</p>
                        </div>
                        <div class="portal-arrow">→</div>
                    </a>
                    
                    <a href="index.php?role=doctor" class="portal-card">
                        <div class="portal-icon">👨‍⚕️</div>
                        <div class="portal-info">
                            <h3>Doctor Portal</h3>
                            <p>View schedule, write prescriptions & manage records</p>
                        </div>
                        <div class="portal-arrow">→</div>
                    </a>
                </div>
                
                <div class="demo-credentials">
                    <div class="demo-title">🔐 Demo Credentials</div>
                    <div class="demo-item">Patient: james.a@email.com / 123456</div>
                    <div class="demo-item">Doctor: dr.smith@clinic.com / 123456</div>
                    <div class="demo-item">Nurse: emily.j@clinic.com / 123456</div>
                </div>
                
                <div class="register-link">
                    <a href="register.php">📝 New patient? Register here</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>