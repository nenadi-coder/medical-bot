<?php
require_once 'config.php';

if (isset($_GET['telegram_user_id']) && isset($_GET['patient_id'])) {

    $stmt = $pdo->prepare("
        UPDATE patients 
        SET telegram_user_id = ?
        WHERE patient_id = ?
    ");

    $stmt->execute([
        $_GET['telegram_user_id'],
        $_GET['patient_id']
    ]);

    echo "OK";
}