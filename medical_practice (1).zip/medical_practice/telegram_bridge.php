<?php
require_once __DIR__ . '/includes/config.php';
header('Content-Type: application/json');

// Get the request
$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? '';

// Simple logging for debugging
$log_file = __DIR__ . '/telegram_log.txt';
file_put_contents($log_file, date('Y-m-d H:i:s') . " - Action: $action\n", FILE_APPEND);

try {
    switch($action) {
        case 'get_patient':
            $email = $input['email'];
            $stmt = $pdo->prepare("SELECT patient_id, first_name, last_name, email FROM patients WHERE email = ?");
            $stmt->execute([$email]);
            $patient = $stmt->fetch(PDO::FETCH_ASSOC);
            
            file_put_contents($log_file, "Looking for email: $email - Found: " . ($patient ? 'Yes' : 'No') . "\n", FILE_APPEND);
            
            echo json_encode(['success' => true, 'data' => $patient]);
            break;
            
        case 'link_patient':
            $telegram_id = $input['telegram_id'];
            $email = $input['email'];
            $stmt = $pdo->prepare("UPDATE patients SET telegram_id = ? WHERE email = ?");
            $stmt->execute([$telegram_id, $email]);
            
            file_put_contents($log_file, "Linked Telegram ID: $telegram_id to email: $email\n", FILE_APPEND);
            
            echo json_encode(['success' => true]);
            break;
            
        case 'get_appointments':
            $patient_id = $input['patient_id'];
            $stmt = $pdo->prepare("
                SELECT a.appointment_id, a.appointment_date, a.appointment_time, a.queue_number,
                       CONCAT(d.first_name, ' ', d.last_name) as doctor_name
                FROM appointments a
                LEFT JOIN doctors d ON a.doctor_id = d.doctor_id
                WHERE a.patient_id = ? AND a.status IN ('scheduled', 'confirmed')
                AND a.appointment_date >= CURDATE()
                ORDER BY a.appointment_date ASC, a.appointment_time ASC
            ");
            $stmt->execute([$patient_id]);
            $appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            file_put_contents($log_file, "Got " . count($appointments) . " appointments for patient ID: $patient_id\n", FILE_APPEND);
            
            echo json_encode(['success' => true, 'data' => $appointments]);
            break;
            
        default:
            echo json_encode(['success' => false, 'error' => 'Unknown action: ' . $action]);
    }
} catch (Exception $e) {
    file_put_contents($log_file, "ERROR: " . $e->getMessage() . "\n", FILE_APPEND);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>