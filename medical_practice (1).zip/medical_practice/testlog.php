<?php
require_once 'includes/config.php';

$email = 'test@example.com'; // CHANGE THIS to an email from your database
$password = 'password123'; // CHANGE THIS to the password for that email

$stmt = $pdo->prepare("SELECT patient_id, first_name, last_name, email FROM patients WHERE email = ? AND password = ?");
$stmt->execute([$email, $password]);
$patient = $stmt->fetch(PDO::FETCH_ASSOC);

echo "<pre>";
if ($patient) {
    echo "SUCCESS! Patient found:\n";
    print_r($patient);
} else {
    echo "FAILED! No patient found with email: $email and that password";
    
    // Check if email exists
    $checkStmt = $pdo->prepare("SELECT email FROM patients WHERE email = ?");
    $checkStmt->execute([$email]);
    if ($checkStmt->rowCount() > 0) {
        echo "\n\nEmail exists but password is wrong.";
    } else {
        echo "\n\nEmail does not exist in database.";
    }
}
echo "</pre>";
?>