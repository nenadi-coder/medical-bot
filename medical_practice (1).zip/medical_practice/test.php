<?php
require_once 'includes/config.php';
header('Content-Type: application/json');

try {
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM patients");
    $result = $stmt->fetch();
    echo json_encode(['success' => true, 'patient_count' => $result['count']]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>