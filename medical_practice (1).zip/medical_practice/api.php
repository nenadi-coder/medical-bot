<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'includes/config.php';
header('Content-Type: application/json');

// Get request data
$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? '';

// Security key
$SECRET_KEY = 'mySecretKey123';
if (!isset($input['key']) || $input['key'] !== $SECRET_KEY) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

try {
    switch($action) {
        case 'register':
            $first_name = $input['first_name'] ?? '';
            $last_name = $input['last_name'] ?? '';
            $email = strtolower($input['email'] ?? '');
            $phone = $input['phone'] ?? '';
            $password = $input['password'] ?? '';
            $date_of_birth = $input['date_of_birth'] ?? '';
            
            // Check if email exists
            $check = $pdo->prepare("SELECT patient_id FROM patients WHERE email = ?");
            $check->execute([$email]);
            if ($check->rowCount() > 0) {
                echo json_encode(['success' => false, 'error' => 'Email already exists']);
                exit();
            }
            
            // Insert patient
            $stmt = $pdo->prepare("INSERT INTO patients (first_name, last_name, email, phone, password, date_of_birth) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$first_name, $last_name, $email, $phone, $password, $date_of_birth]);
            
            echo json_encode(['success' => true, 'message' => 'Registration successful']);
            break;
            
        case 'login':
            $email = strtolower($input['email'] ?? '');
            $password = $input['password'] ?? '';
            
            $stmt = $pdo->prepare("SELECT patient_id, first_name, last_name, email FROM patients WHERE email = ? AND password = ?");
            $stmt->execute([$email, $password]);
            $patient = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($patient) {
                echo json_encode([
                    'success' => true,
                    'patient_id' => $patient['patient_id'],
                    'first_name' => $patient['first_name'],
                    'last_name' => $patient['last_name'],
                    'email' => $patient['email']
                ]);
            } else {
                echo json_encode(['success' => false, 'error' => 'Invalid email or password']);
            }
            break;
            
        case 'check_email':
            $email = strtolower($input['email'] ?? '');
            
            $stmt = $pdo->prepare("SELECT patient_id, first_name, last_name FROM patients WHERE email = ?");
            $stmt->execute([$email]);
            $patient = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($patient) {
                echo json_encode([
                    'success' => true,
                    'exists' => true,
                    'first_name' => $patient['first_name'],
                    'last_name' => $patient['last_name']
                ]);
            } else {
                echo json_encode(['success' => true, 'exists' => false]);
            }
            break;
            
        default:
            echo json_encode(['success' => false, 'error' => 'Unknown action: ' . $action]);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'Server error: ' . $e->getMessage()]);
}
?>